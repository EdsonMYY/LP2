﻿namespace PCalculo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lbl1 = new System.Windows.Forms.Label();
            this.Lbl2 = new System.Windows.Forms.Label();
            this.LblResultado = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.BtnSinalMais = new System.Windows.Forms.Button();
            this.BtnSinalMenos = new System.Windows.Forms.Button();
            this.BtnSinalVezes = new System.Windows.Forms.Button();
            this.BtnDivisão = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Lbl1
            // 
            this.Lbl1.AutoSize = true;
            this.Lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl1.Location = new System.Drawing.Point(350, 161);
            this.Lbl1.Name = "Lbl1";
            this.Lbl1.Size = new System.Drawing.Size(78, 20);
            this.Lbl1.TabIndex = 0;
            this.Lbl1.Text = "Número 1";
            // 
            // Lbl2
            // 
            this.Lbl2.AutoSize = true;
            this.Lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl2.Location = new System.Drawing.Point(350, 197);
            this.Lbl2.Name = "Lbl2";
            this.Lbl2.Size = new System.Drawing.Size(78, 20);
            this.Lbl2.TabIndex = 1;
            this.Lbl2.Text = "Número 2";
            // 
            // LblResultado
            // 
            this.LblResultado.AutoSize = true;
            this.LblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblResultado.Location = new System.Drawing.Point(350, 257);
            this.LblResultado.Name = "LblResultado";
            this.LblResultado.Size = new System.Drawing.Size(82, 20);
            this.LblResultado.TabIndex = 2;
            this.LblResultado.Text = "Resultado";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(477, 163);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(140, 20);
            this.txt1.TabIndex = 3;
            this.txt1.Validated += new System.EventHandler(this.Txt1_Validated);
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(477, 199);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(140, 20);
            this.txt2.TabIndex = 4;
            this.txt2.Validated += new System.EventHandler(this.Txt2_Validated);
            // 
            // txtResultado
            // 
            this.txtResultado.Enabled = false;
            this.txtResultado.Location = new System.Drawing.Point(477, 259);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(140, 20);
            this.txtResultado.TabIndex = 5;
            // 
            // BtnSinalMais
            // 
            this.BtnSinalMais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSinalMais.Location = new System.Drawing.Point(330, 317);
            this.BtnSinalMais.Name = "BtnSinalMais";
            this.BtnSinalMais.Size = new System.Drawing.Size(85, 38);
            this.BtnSinalMais.TabIndex = 6;
            this.BtnSinalMais.Text = "+";
            this.BtnSinalMais.UseVisualStyleBackColor = true;
            this.BtnSinalMais.Click += new System.EventHandler(this.BtnSinalMais_Click);
            // 
            // BtnSinalMenos
            // 
            this.BtnSinalMenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSinalMenos.Location = new System.Drawing.Point(441, 317);
            this.BtnSinalMenos.Name = "BtnSinalMenos";
            this.BtnSinalMenos.Size = new System.Drawing.Size(85, 38);
            this.BtnSinalMenos.TabIndex = 7;
            this.BtnSinalMenos.Text = "-";
            this.BtnSinalMenos.UseVisualStyleBackColor = true;
            this.BtnSinalMenos.Click += new System.EventHandler(this.BtnSinalMenos_Click);
            // 
            // BtnSinalVezes
            // 
            this.BtnSinalVezes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSinalVezes.Location = new System.Drawing.Point(548, 317);
            this.BtnSinalVezes.Name = "BtnSinalVezes";
            this.BtnSinalVezes.Size = new System.Drawing.Size(85, 38);
            this.BtnSinalVezes.TabIndex = 8;
            this.BtnSinalVezes.Text = "*";
            this.BtnSinalVezes.UseVisualStyleBackColor = true;
            this.BtnSinalVezes.Click += new System.EventHandler(this.BtnSinalVezes_Click);
            // 
            // BtnDivisão
            // 
            this.BtnDivisão.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDivisão.Location = new System.Drawing.Point(658, 317);
            this.BtnDivisão.Name = "BtnDivisão";
            this.BtnDivisão.Size = new System.Drawing.Size(85, 38);
            this.BtnDivisão.TabIndex = 9;
            this.BtnDivisão.Text = "/";
            this.BtnDivisão.UseVisualStyleBackColor = true;
            this.BtnDivisão.Click += new System.EventHandler(this.BtnDivisão_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(686, 156);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(85, 33);
            this.BtnLimpar.TabIndex = 10;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(686, 208);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(85, 33);
            this.BtnSair.TabIndex = 11;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1190, 718);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnDivisão);
            this.Controls.Add(this.BtnSinalVezes);
            this.Controls.Add(this.BtnSinalMenos);
            this.Controls.Add(this.BtnSinalMais);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.LblResultado);
            this.Controls.Add(this.Lbl2);
            this.Controls.Add(this.Lbl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl1;
        private System.Windows.Forms.Label Lbl2;
        private System.Windows.Forms.Label LblResultado;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button BtnSinalMais;
        private System.Windows.Forms.Button BtnSinalMenos;
        private System.Windows.Forms.Button BtnSinalVezes;
        private System.Windows.Forms.Button BtnDivisão;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnSair;
    }
}

