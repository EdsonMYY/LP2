﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculo
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado; //Globais

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Txt1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txt1.Text, out Numero1))
            {
                MessageBox.Show("Número inválido!");
                // txt1.Focus();
            }
        }

        private void Txt2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txt2.Text, out Numero2))
            {
                MessageBox.Show("Número inválido!");
                // txt2.Focus();
            }
        }

        private void BtnSinalMais_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Numero1) && double.TryParse(txt2.Text, out Numero2))
            {
                Resultado = Numero1 + Numero2;
                txtResultado.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Número inválidos!!");
        }

        private void BtnSinalMenos_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Numero1) && double.TryParse(txt2.Text, out Numero2))
            {
                Resultado = Numero1 - Numero2;
                txtResultado.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Número inválidos!!");
        }

        private void BtnSinalVezes_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Numero1) && double.TryParse(txt2.Text, out Numero2))
            {
                Resultado = Numero1 * Numero2;
                txtResultado.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Número inválidos!!");
        }

        private void BtnDivisão_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Numero1) && double.TryParse(txt2.Text, out Numero2))
            {
                if(Numero2!=0)
                {
                    Resultado = Numero1 / Numero2;
                    txtResultado.Text = Resultado.ToString();
                }
                else
                    MessageBox.Show("Divisão por Zero");
            }
            else
                MessageBox.Show("Número inválidos!!");
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            /*txt1.Text = "";
              txt2.Text = "";
              txtResultado.Text = "";

            Ou
              
              txt1.Text = String.Empty;
              txt2.Text = String.Empty;
              txtResultado.Text = String.Empty;

            Ou
            */
            txt1.Clear();
            txt2.Clear();
            txtResultado.Clear();
        }
    }
}
