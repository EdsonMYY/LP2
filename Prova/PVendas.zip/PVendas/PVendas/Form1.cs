﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            double[,] totalVendas = new double[2, 4];
            string vendas;
            double somaM1 = 0, somaM2 = 0, resultado =0;
            int linha, coluna;

            lbxVendas.Items.Clear();

            for (linha = 0; linha < 2; linha++)
            {
                for (coluna = 0; coluna < 4; coluna++)
                {
                    vendas = Interaction.InputBox("Total mês: " + (linha + 1).ToString() + " \nInsira o valor de vendas da semana " + (coluna + 1).ToString());
                    if (!double.TryParse(vendas, out totalVendas[linha, coluna])) //verifica se e caracter ou numero
                    {
                        MessageBox.Show("O valor deve ser apenas número\nTente outra vez Raulzito");
                        coluna--;
                    }
                    lbxVendas.Items.Add("Total do mês: " + (linha + 1).ToString() + "     Semana: " + (coluna + 1).ToString() + " = " + vendas);
                    somaM1 += ((totalVendas[0, coluna]));
                    somaM2 += ((totalVendas[1, coluna]));
                }
                lbxVendas.Items.Add(" ");
                lbxVendas.Items.Add("Total de vendas mês:R$ " + somaM1.ToString("N2"));
                lbxVendas.Items.Add("Total de vendas mês:R$ " + somaM2.ToString("N2"));
            }
            resultado = somaM1 + somaM2;
            lbxVendas.Items.Add("Total Geral:R$ " + resultado);
        }
    }
}
